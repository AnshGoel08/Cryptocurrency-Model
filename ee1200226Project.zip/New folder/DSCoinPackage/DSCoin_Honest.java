package DSCoinPackage;

public class DSCoin_Honest {

  public TransactionQueue pendingTransactions;
  public BlockChain_Honest bChain;
  public Members[] memberlist;
  public String latestCoinID;
}
