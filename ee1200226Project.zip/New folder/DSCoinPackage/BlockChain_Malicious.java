package DSCoinPackage;
import java.util.*;
import HelperClasses.CRF;
import HelperClasses.*;


public class BlockChain_Malicious {

  public int tr_count;
  public static final String start_string = "DSCoin";
  public TransactionBlock[] lastBlocksList;

  public static boolean checkTransactionBlock (TransactionBlock tB) {
    CRF crf = new CRF(64);
	boolean x = false;
	boolean y = false;
	boolean z = true;
    if(tB.previous == null){
      if(tB.dgst.substring(0,4).equals("0000") && tB.dgst.equals(crf.Fn(start_string + "#" + tB.trsummary+ "#" + tB.nonce))){
        x = true;
    }
	}
    else{
      if(tB.dgst.substring(0,4).equals("0000") && tB.dgst.equals(crf.Fn(tB.previous.dgst+ "#" + tB.trsummary+ "#" + tB.nonce))){
        x = true;
      }
    }

    MerkleTree tree2 = new MerkleTree();
    String a = tree2.Build(tB.trarray);
    if(tB.trsummary.equals(a)){
      y = true;
    }
	if(tB.previous!= null){
		for(int i =0; i < tB.trarray.length ;i++){
      if(tB.previous.checkTransaction(tB.trarray[i]) == false){
		  
        z = false;
        break;
      }
      else{
        z = true;
      }
    }
	}
    

    if(x==true && y==true && z==true){
      return true;
    }
    else{
      return false;
    }
	
  }   

  public TransactionBlock FindLongestValidChain(){
    int c = 0;
    int lastlength = lastBlocksList.length;
    List<Pair<TransactionBlock, String>> plist = new ArrayList<Pair<TransactionBlock, String>>();

	int m=0;
      while(lastBlocksList[m]!=null){
        m++;
      }
    if (m == 0){
      return null;
    }
    else{
      for(int i=0; i< m; i++){
        TransactionBlock pointer1 = lastBlocksList[i];
        TransactionBlock pointer2 = lastBlocksList[i];
		if(pointer1 == null){
			break;
		}
        while(pointer1.previous != null){
          if(checkTransactionBlock(pointer1) == false){
            pointer2 = pointer1.previous; 
            c -= 1;
          }
          pointer1 = pointer1.previous;
          c++;
        }
		Pair<TransactionBlock, String> pair1 = new Pair<TransactionBlock, String>(pointer2,Integer.toString(c));
        plist.add(pair1);
       
      }
      
      TransactionBlock valblock = plist.get(0).first;
      int max = Integer.parseInt(plist.get(0).second);
      for(int i =0;i < m;i++){
		  if(lastBlocksList[i] == null){
			  break;
		  }
        else if(Integer.parseInt(plist.get(i).second) > max){
          max = Integer.parseInt(plist.get(i).second);
          valblock = plist.get(i).first;
        }
      }
    return valblock;  

    }  
  }

  public void InsertBlock_Malicious(TransactionBlock newBlock){
    CRF crf = new CRF(64);
    TransactionBlock lastBlock = this.FindLongestValidChain();
    
    if(lastBlock == null){
      String s = "1000000001";
      
      while(! crf.Fn(start_string + "#" + newBlock.trsummary+ "#" + s).substring(0,4).equals("0000")) {
        int n = Integer.parseInt(s) + 1;
        s = Integer.toString(n);
      }
      newBlock.nonce = s;
      newBlock.dgst = crf.Fn(start_string + "#" + newBlock.trsummary+ "#" + newBlock.nonce);
      lastBlock = newBlock;
      newBlock.next = null;
      newBlock.previous = null;
	  lastBlocksList[0] = newBlock;

    }
    else{ 
      String s = "1000000001";
      while(! crf.Fn(lastBlock.dgst+ "#" + newBlock.trsummary+ "#" + s).substring(0,4).equals("0000")){
        int n = Integer.parseInt(s) + 1;
        s = Integer.toString(n);
      }
      newBlock.nonce = s;
      newBlock.dgst= crf.Fn(lastBlock.dgst+ "#" + newBlock.trsummary+ "#" + newBlock.nonce);
      lastBlock.next = newBlock;
      newBlock.previous = lastBlock;
      
      int lastlength = lastBlocksList.length;

      boolean h=true;
            for(int i=0;i<lastBlocksList.length;i++){
              if(lastBlock==this.lastBlocksList[i]){
                this.lastBlocksList[i]=newBlock;
                h = false;
                break;
              }
            }
            if(h==true){
              for(int q=0;q<lastBlocksList.length;q++){
                if(lastBlocksList[q]==null){
                  lastBlocksList[q]=newBlock;
                  break;
                }
              }
            }
    }   
  }
}
