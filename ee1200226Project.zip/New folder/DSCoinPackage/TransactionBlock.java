package DSCoinPackage;

import HelperClasses.MerkleTree;
import HelperClasses.CRF;

public class TransactionBlock {

  public Transaction[] trarray;
  public TransactionBlock previous;
  public TransactionBlock next;
  public MerkleTree Tree;
  public String trsummary;
  public String nonce;
  public String dgst;

  TransactionBlock(Transaction[] t) {
    
    this.trarray = t;
    this.previous = null;
    MerkleTree tree1 = new MerkleTree();
    String bui = tree1.Build(t);
    this.Tree = tree1;
    this.trsummary = bui;
    this.dgst = null;
  }

  public boolean checkTransaction (Transaction t) {
    
    int trcount = trarray.length;
	if(t.coinsrc_block == null){
		return true;
	}
    for(int i =0; i<trcount ;i++){
      if( t.coinsrc_block.trarray[i].coinID.equals(t.coinID)  && t.coinsrc_block.trarray[i].Destination.UID.equals(t.Source.UID)){
        return true;
      }
    }
	
    TransactionBlock thB = this;
    while(thB != t.coinsrc_block){
      for(int i =0; i<trcount ;i++){
        if(thB.trarray[i].coinID.equals(t.coinID)){
          return false; 
        }
      }
      thB = thB.previous;
    }
    return false;
  }
}
