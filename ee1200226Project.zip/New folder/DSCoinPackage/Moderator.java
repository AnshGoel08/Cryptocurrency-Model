package DSCoinPackage;
import HelperClasses.*;
public class Moderator
 {

   public void initializeDSCoin(DSCoin_Honest DSObj, int coinCount) {
	Members p = new Members();
	p.UID = "Moderator";
	int total = coinCount;
	int x = 0;
	int y = 100000;
	
	int z=0;
	while(total>0){
		Transaction[] array = new Transaction[DSObj.bChain.tr_count];
		for(int i=0; i<array.length; i++){
			Transaction t = new Transaction();
			t.Source = p;
			t.Destination = DSObj.memberlist[x];
			t.coinID = Integer.toString(y);
			t.coinsrc_block = null;
			DSObj.latestCoinID = t.coinID;
			array[i] = t;
			total--;
			y++;
			x++;
			x=x%(DSObj.memberlist.length);
			
	
	
		}
		TransactionBlock newBlock = new TransactionBlock(array);
		
			
			for(int i=0;i<array.length;i++){
				Pair<String, TransactionBlock> px = new Pair<String, TransactionBlock>(array[i].coinID,newBlock);
				DSObj.memberlist[z].mycoins.add(px);
				z++;
				z=z%(DSObj.memberlist.length);
			}
		DSObj.bChain.InsertBlock_Honest(newBlock);
	}	
  }
    
  public void initializeDSCoin(DSCoin_Malicious DSObj, int coinCount) {
	Members p = new Members();
	p.UID = "Moderator";
	int total = coinCount;
	int x = 0;
	int y = 100000;
	
	int z=0;
	while(total>0){
		Transaction[] array = new Transaction[DSObj.bChain.tr_count];
		for(int i=0; i<array.length; i++){
			Transaction t = new Transaction();
			t.Source = p;
			t.Destination = DSObj.memberlist[x];
			t.coinID = Integer.toString(y);
			t.coinsrc_block = null;
			DSObj.latestCoinID = t.coinID;
			array[i] = t;
			total--;
			y++;
			x++;
			x=x%(DSObj.memberlist.length);
			
	
	
		}
		TransactionBlock newBlock = new TransactionBlock(array);
		
			
			for(int i=0;i<array.length;i++){
				Pair<String, TransactionBlock> px = new Pair<String, TransactionBlock>(array[i].coinID,newBlock);
				DSObj.memberlist[z].mycoins.add(px);
				z++;
				z=z%(DSObj.memberlist.length);
			}
		DSObj.bChain.InsertBlock_Malicious(newBlock);	
	}
  }
}
