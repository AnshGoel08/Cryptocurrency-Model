package DSCoinPackage;


public class TransactionQueue {

  public Transaction firstTransaction;
  public Transaction lastTransaction;
  public int numTransactions;

  public void AddTransactions (Transaction transaction) {
	if(firstTransaction == null){
		firstTransaction = transaction;
		lastTransaction = transaction;
	}
	else{
    lastTransaction.next = transaction;
    transaction.previous = lastTransaction;
    lastTransaction = transaction;
    
	}
	numTransactions += 1;
  }
  
  public Transaction RemoveTransaction () throws EmptyQueueException {
	Transaction temp = firstTransaction;
	
    if (numTransactions != 0){
		
      firstTransaction = firstTransaction.next;
	  if(numTransactions != 1){
		  firstTransaction.previous = null;
	  }
      numTransactions -= 1;
		}	
		else{
			throw new EmptyQueueException();
	}	
    
    return temp;
  }

  public int size() {

    return numTransactions;
  }
}
