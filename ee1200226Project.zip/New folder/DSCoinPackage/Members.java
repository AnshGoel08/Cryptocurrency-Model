package DSCoinPackage;

import java.util.*;
import HelperClasses.*;

public class Members
 {

  public String UID;
  public List<Pair<String, TransactionBlock>> mycoins;
  public Transaction[] in_process_trans = new Transaction[100];

  public static boolean Valid(Transaction d, Transaction[] dar,DSCoin_Honest DSObj){
    TransactionBlock tB = d.coinsrc_block;
    boolean q = false;
    if(tB != null){
      for (int i = 0; i<tB.trarray.length; i++){
        Transaction d1 = tB.trarray[i];
        if((d1.coinID.equals(d.coinID)) && (d1.Destination.UID.equals(d.Source.UID))){
          q = true;
        }
      }
    }
    boolean r = true;
    for (int i = 0; i<dar.length;i++){
      if(dar[i] == null){
        break;

      }
      else if(dar[i].coinID.equals(d.coinID)){
        r = false;
        break;
      }
    }
    boolean s = true;
    TransactionBlock B = DSObj.bChain.lastBlock;
    while(B != d.coinsrc_block){
      for(int i =0;i<B.trarray.length; i++){
        if(B.trarray[i].coinID.equals(d.coinID)){
          s = false;
          break;
        }
      }
      if(s == true){
        B = B.previous;
      }
	  if(s == false){break;}
    }
    return (q && r && s);
  }

  public static boolean ValidM(Transaction d, Transaction[] dar,DSCoin_Malicious DSObj){
    TransactionBlock tB = d.coinsrc_block;
    boolean q = false;
    if(tB != null){
      for (int i = 0; i<tB.trarray.length; i++){
        Transaction d1 = tB.trarray[i];
        if((d1.coinID.equals(d.coinID)) && (d1.Destination.UID.equals(d.Source.UID))){
          q = true;
        }
      }
    }
    boolean r = true;
    for (int i = 0; i<dar.length;i++){
      if(dar[i] == null){
        break;

      }
      else if(dar[i].coinID.equals(d.coinID)){
        r = false;
        break;
      }
    }
    boolean s = true;
    TransactionBlock B = DSObj.bChain.FindLongestValidChain();
    while(B != d.coinsrc_block){
      for(int i =0;i<B.trarray.length; i++){
        if(B.trarray[i].coinID.equals(d.coinID)){
          s = false;
          break;
        }
      }
      if(s = true){
        B = B.previous;
      }
    }
    return (q && r && s);
  }


  public void initiateCoinsend(String destUID, DSCoin_Honest DSobj) {

    
    Transaction tobj = new Transaction();
    tobj.coinID = mycoins.get(0).get_first();
    tobj.Source = this;
    tobj.coinsrc_block = mycoins.get(0).get_second();

    for(int i = 0;i < DSobj.memberlist.length;i++){
      if(DSobj.memberlist[i].UID == destUID){
        tobj.Destination = DSobj.memberlist[i];
        break;
      }
    }
    mycoins.remove(0);

    for(int i =0;i < in_process_trans.length;i++){
      if(in_process_trans[i] == null){
        in_process_trans[i] = tobj;
        break;
      } 
    }
    
    DSobj.pendingTransactions.AddTransactions(tobj);

  }
  /*public void initiateCoinsend(String destUID, DSCoin_Malicious DSobj) {

    
    Transaction tobj = new Transaction();
    tobj.coinID = mycoins.get(0).get_first();
    tobj.Source = this;
    tobj.coinsrc_block = mycoins.get(0).get_second();

    for(int i = 0;i < DSobj.memberlist.length;i++){
      if(DSobj.memberlist[i].UID == destUID){
        tobj.Destination = DSobj.memberlist[i];
        break;
      }
    }
    mycoins.remove(0);

    for(int i =0;i < in_process_trans.length;i++){
      if(in_process_trans[i] == null){
        in_process_trans[i] = tobj;
        break;
      } 
    }
    
    DSobj.pendingTransactions.AddTransactions(tobj);

  }*/


  public Pair<List<Pair<String, String>>, List<Pair<String, String>>> finalizeCoinsend (Transaction tobj, DSCoin_Honest DSObj) throws MissingTransactionException {
    TransactionBlock tB = DSObj.bChain.lastBlock;
	boolean l= false;
	int i =0;
    while(tB != null){
      for(i =0; i < tB.trarray.length;i++){
		  
        if(tB.trarray[i] == tobj){
		  l = true;
		  break;
		}
	  }	
	  if(l){ 
		break;
	  }
	  tB = tB.previous;
	}
	  if(!l){
		throw new MissingTransactionException();
	  } 
	   else{
		  TreeNode curr = new TreeNode();
		  curr = tB.Tree.rootnode;
          int y = tB.trarray.length/2;
          while (y>0) {
            if (i>y){
              i -= y;
              curr = curr.right;
            } else {
              curr = curr.left;
            }
            y /= 2;
          }

          List<Pair<String,String>> l1 = new ArrayList<Pair<String,String>>();
          
          while(curr.parent != null){
            Pair<String,String> n = new Pair<String,String>(curr.parent.left.val,curr.parent.right.val);
            
            l1.add(n);
			curr = curr.parent;
          }
          Pair<String,String> X = new Pair<String,String>(curr.val,null);
		      
		      l1.add(X);

          List<Pair<String,String>> l2 = new ArrayList<Pair<String,String>>();
          Pair<String,String> n2 = new Pair<String,String>(tB.previous.dgst,null);  
          

          TransactionBlock last = DSObj.bChain.lastBlock;
          while(last != tB.previous){
            Pair<String,String> n3 = new Pair<String,String>(last.dgst,last.previous.dgst + "#" + last.trsummary + "#" + last.nonce);
            l2.add(n3);
			last= last.previous;
          }
		  l2.add(n2);
		  Collections.reverse(l2);

          for(int x = 0;in_process_trans[x] != null;x++){
            if(in_process_trans[x] == tobj){
              for(int k=x;in_process_trans[k] != null;k++){
                if(in_process_trans[k+1] == null){
                  in_process_trans[k] = null;
                }
                else{
                  in_process_trans[k] = in_process_trans[k+1];
                }
              }
              break;
            }
          }

          Pair<String, TransactionBlock> t = new Pair<String, TransactionBlock>(tobj.coinID,tB);
		  boolean ini = false;
		  for(int z = 0;z<tobj.Destination.mycoins.size(); z++){
			  if(t.first.compareTo(tobj.Destination.mycoins.get(z).first)<0){
				  tobj.Destination.mycoins.add(z,t);
				  ini = true;
				  break;
			  }
		  }
		  if(!ini){
			  tobj.Destination.mycoins.add(t);
		  }
          
          
          Pair<List<Pair<String, String>>, List<Pair<String, String>>> L = new Pair<List<Pair<String, String>>, List<Pair<String, String>>>(l1,l2);
          return L; 
	   }
	

  }

  public void MineCoin(DSCoin_Honest DSObj) {
    
    int a = DSObj.bChain.tr_count;
    int g = 0;
    Transaction[] lis = new Transaction[a];
    while(g< a-1){
      try{
      Transaction b = DSObj.pendingTransactions.RemoveTransaction();
      if(Valid(b, lis,DSObj)){
        lis[g] = b;
        g++;
      }
    }
	
	catch (Exception EmptyQueueException){
		System.out.println("ksjdbv");
	}
	}
	
    Transaction minerRewardTransaction = new Transaction();
    minerRewardTransaction.Source = null;
    minerRewardTransaction.Destination = this;
    minerRewardTransaction.coinsrc_block = null;
    minerRewardTransaction.coinID = Integer.toString(Integer.parseInt(DSObj.latestCoinID) + 1);
    lis[a-1]= minerRewardTransaction;
    DSObj.latestCoinID = Integer.toString(Integer.parseInt(DSObj.latestCoinID)+1);

    
    TransactionBlock tB = new TransactionBlock(lis);
    DSObj.bChain.InsertBlock_Honest(tB);
    Pair<String,TransactionBlock> T = new Pair<String,TransactionBlock>(minerRewardTransaction.coinID,tB);
    this.mycoins.add(T);
  }
  

  public void MineCoin(DSCoin_Malicious DSObj){
    int a = DSObj.bChain.tr_count;
    int g = 0;
    Transaction[] lis = new Transaction[a];
    while(g< a-1){
      try{
      Transaction b = DSObj.pendingTransactions.RemoveTransaction();
      if(ValidM(b, lis,DSObj)){
        lis[g] = b;
        g++;
      }
    }
	
	catch (Exception EmptyQueueException){
		System.out.println("ksjdbv");
	}
	}
	
    Transaction minerRewardTransaction = new Transaction();
    minerRewardTransaction.Source = null;
    minerRewardTransaction.Destination = this;
    minerRewardTransaction.coinsrc_block = null;
    minerRewardTransaction.coinID = Integer.toString(Integer.parseInt(DSObj.latestCoinID) + 1);
    lis[a-1]= minerRewardTransaction;
    DSObj.latestCoinID = Integer.toString(Integer.parseInt(DSObj.latestCoinID)+1);

    
    TransactionBlock tB = new TransactionBlock(lis);
    DSObj.bChain.InsertBlock_Malicious(tB);
    Pair<String,TransactionBlock> T = new Pair<String,TransactionBlock>(minerRewardTransaction.coinID,tB);
    this.mycoins.add(T);

  }  
}
