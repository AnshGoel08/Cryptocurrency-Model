package DSCoinPackage;

import HelperClasses.CRF;

public class BlockChain_Honest {

  public int tr_count;
  public static final String start_string = "DSCoin";
  public TransactionBlock lastBlock;

  public void InsertBlock_Honest (TransactionBlock newBlock) {
    CRF crf = new CRF(64);
    
    if(lastBlock == null){
      String s = "1000000001";
      
      while(! crf.Fn(start_string + "#" + newBlock.trsummary+ "#" + s).substring(0,4).equals("0000")) {
        int n = Integer.parseInt(s) + 1;
        s = Integer.toString(n);
      }
      newBlock.nonce = s;
      newBlock.dgst = crf.Fn(start_string + "#" + newBlock.trsummary+ "#" + newBlock.nonce);
      lastBlock = newBlock;
      newBlock.next = null;
      newBlock.previous = null;

    }
    else{ 
      String s = "1000000001";
      while(! crf.Fn(lastBlock.dgst+ "#" + newBlock.trsummary+ "#" + s).substring(0,4).equals("0000")){
        int n = Integer.parseInt(s) + 1;
        s = Integer.toString(n);
      }
      newBlock.nonce = s;
      newBlock.dgst= crf.Fn(lastBlock.dgst+ "#" + newBlock.trsummary+ "#"+ newBlock.nonce);
      lastBlock.next = newBlock;
      newBlock.previous = lastBlock;
      lastBlock = newBlock;
    }   
  }
}
